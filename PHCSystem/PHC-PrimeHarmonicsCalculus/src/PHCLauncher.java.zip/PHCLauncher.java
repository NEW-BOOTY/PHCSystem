/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 *
 * PHCLauncher.java
 * Entry launcher for the Prime Harmonics Calculus interpreter system.
 * Supports interactive CLI + JavaFX interface with visualizations and zero analysis.
 */

import core.PHCInterpreter;
import javafx.application.Application;
import javafx.stage.Stage;
import java.util.Scanner;

public final class PHCLauncher extends Application {

    private static PHCInterpreter interpreter;

    /**
     * Main entry point from JVM
     * @param args optional command-line arguments
     */
    public static void main(String[] args) {
        try {
            // Launch JavaFX
            launch(args);
        } catch (Exception ex) {
            System.err.println("[PHC FATAL ERROR] Interpreter failed to launch: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            interpreter = new PHCInterpreter(primaryStage);
            System.out.println("=== Prime Harmonics Calculus (PHC) ===");
            System.out.println("Type 'visualize', 'scan 0 50', 'animate', or 'exit'");
            runInteractiveLoop();
        } catch (Exception e) {
            System.err.println("[PHC BOOT ERROR] " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Simple CLI loop for PHC interaction.
     */
    private void runInteractiveLoop() {
        Scanner scanner = new Scanner(System.in);
        String line;

        while (true) {
            System.out.print("PHC> ");
            line = scanner.nextLine();

            if (line == null || line.trim().isEmpty()) continue;

            if (line.equalsIgnoreCase("exit") || line.equalsIgnoreCase("quit")) {
                System.out.println("Goodbye.");
                System.exit(0);
            }

            try {
                interpreter.interpret(line);
            } catch (Exception ex) {
                System.err.println("[PHC ERROR] Command failed: " + ex.getMessage());
            }
        }
    }
}
