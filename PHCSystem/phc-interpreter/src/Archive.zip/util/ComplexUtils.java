/*
 * Copyright © 2024 Devin B. Royal.
 * All Rights Reserved.
 *
 * ComplexUtils.java
 * Mathematical primitives for PHC symbolic functions and harmonic encodings.
 */

package symbolic.util;

import symbolic.log.Logger;

public final class ComplexUtils {

    private ComplexUtils() {
        // Prevent instantiation
    }

    /**
     * Hypothetical PHC kernel primitive — user-defined for symbolic harmonic evaluation.
     * Example placeholder until real theoretical structure is imposed.
     */
    public static double phcKernel(double input) {
        try {
            if (input == 0.0) throw new ArithmeticException("Division by zero in phcKernel");

            double harmonicSum = 0.0;
            for (int n = 1; n <= 100; n++) {
                harmonicSum += Math.pow(input, -n) / Math.pow(n, input);
            }

            return harmonicSum;
        } catch (Exception e) {
            Logger.error("phcKernel failed: " + e.getMessage());
            return Double.NaN;
        }
    }

    public static boolean approxEqual(double a, double b, double tolerance) {
        return Math.abs(a - b) <= tolerance;
    }
}
