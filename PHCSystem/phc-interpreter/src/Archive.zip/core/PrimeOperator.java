/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 *
 * PrimeField.java
 * Simulates the dynamic superposition of spectral primes in ℝ³.
 * Calculates real/imaginary projections, interference intensity, and nodal zeros.
 */

package core;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public final class PrimeField {

    // List of spectral primes active in this field
    private final List<SpectralPrime> primes;

    /**
     * Constructs an empty PrimeField.
     */
    public PrimeField() {
        this.primes = new CopyOnWriteArrayList<>();
    }

    /**
     * Adds a spectral prime to the field.
     * @param prime SpectralPrime object
     */
    public void addPrime(SpectralPrime prime) {
        Objects.requireNonNull(prime, "Cannot add null spectral prime.");
        primes.add(prime);
    }

    /**
     * Clears all primes from the field.
     */
    public void reset() {
        primes.clear();
    }

    /**
     * Returns the number of active primes.
     */
    public int getPrimeCount() {
        return primes.size();
    }

    /**
     * Computes the complex superposition Ω(t) at time t.
     * @param t Time input
     * @return Array [Re(Ω), Im(Ω)]
     */
    public double[] computeFieldAt(double t) {
        double sumRe = 0;
        double sumIm = 0;
        for (SpectralPrime prime : primes) {
            double[] comp = prime.computeSpectralComponents(t);
            sumRe += comp[0];
            sumIm += comp[1];
        }
        return new double[]{sumRe, sumIm};
    }

    /**
     * Computes the modulus |Ω(t)| at time t.
     * @param t Time input
     * @return Absolute magnitude of total interference
     */
    public double computeModulusAt(double t) {
        double[] sum = computeFieldAt(t);
        return Math.hypot(sum[0], sum[1]);
    }

    /**
     * Searches for approximate time values t where Re(Ω(t)) ≈ 0.
     * This identifies candidate destructive interference nodes.
     * @param tMin Minimum time
     * @param tMax Maximum time
     * @param resolution Time increment for sweep
     * @param epsilon Tolerance for zero condition
     * @return List of zero-candidate times
     */
    public List<Double> locateDestructiveNodes(double tMin, double tMax, double resolution, double epsilon) {
        List<Double> zeros = new ArrayList<>();
        for (double t = tMin; t <= tMax; t += resolution) {
            double[] components = computeFieldAt(t);
            if (Math.abs(components[0]) < epsilon && Math.abs(components[1]) < epsilon) {
                zeros.add(t);
            }
        }
        return zeros;
    }

    /**
     * Summarizes spectral intensity in polar coordinates at t.
     * @param t Time input
     * @return [r = |Ω(t)|, θ = phase angle in radians]
     */
    public double[] getPolarFormAt(double t) {
        double[] c = computeFieldAt(t);
        double r = Math.hypot(c[0], c[1]);
        double theta = Math.atan2(c[1], c[0]);
        return new double[]{r, theta};
    }

    @Override
    public String toString() {
        return String.format("PrimeField with %d active primes", getPrimeCount());
    }
}
