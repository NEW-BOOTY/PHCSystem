/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 *
 * SpectralPrime.java
 * Defines a prime in spectral form: π_i = A_i * exp(i * θ_i(t))
 * Includes phase dynamics, energy amplitude, and complex interference modeling.
 */

package core;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.DoubleUnaryOperator;

public final class SpectralPrime {

    // Static Constants
    private static final double DEFAULT_OMEGA = Math.PI;

    // Prime Identifier
    private final int primeValue;

    // Amplitude A_i
    private final double amplitude;

    // Angular frequency ω_i
    private final double omega;

    // Initial phase offset θ_0
    private final double phaseOffset;

    // Dynamic phase function (user-defined or default θ(t) = ω * t + θ₀)
    private final AtomicReference<DoubleUnaryOperator> phaseFunction;

    /**
     * Constructs a SpectralPrime with custom parameters.
     * @param primeValue The associated prime number (must be prime).
     * @param amplitude Energy amplitude A_i.
     * @param omega Angular frequency ω_i.
     * @param phaseOffset Initial phase θ₀.
     */
    public SpectralPrime(int primeValue, double amplitude, double omega, double phaseOffset) {
        if (primeValue <= 1 || !isPrime(primeValue)) {
            throw new IllegalArgumentException("Input must be a valid prime number.");
        }
        if (amplitude <= 0) {
            throw new IllegalArgumentException("Amplitude must be positive.");
        }

        this.primeValue = primeValue;
        this.amplitude = amplitude;
        this.omega = omega;
        this.phaseOffset = phaseOffset;
        this.phaseFunction = new AtomicReference<>(t -> omega * t + phaseOffset);
    }

    /**
     * Alternate constructor using default ω = π and phase offset = 0.
     */
    public SpectralPrime(int primeValue, double amplitude) {
        this(primeValue, amplitude, DEFAULT_OMEGA, 0);
    }

    /**
     * Sets a custom phase evolution function θ(t).
     * @param thetaFunction A function from t -> θ(t)
     */
    public void setPhaseFunction(DoubleUnaryOperator thetaFunction) {
        Objects.requireNonNull(thetaFunction, "Phase function cannot be null.");
        this.phaseFunction.set(thetaFunction);
    }

    /**
     * Computes the real and imaginary components of π_i(t)
     * @param t Time input
     * @return A double array: [Re, Im]
     */
    public double[] computeSpectralComponents(double t) {
        double theta = phaseFunction.get().applyAsDouble(t);
        double real = amplitude * Math.cos(theta);
        double imag = amplitude * Math.sin(theta);
        return new double[]{real, imag};
    }

    /**
     * Computes the complex modulus |π_i(t)|
     * @param t Time input
     * @return Absolute magnitude
     */
    public double computeModulus(double t) {
        return amplitude; // Constant for given prime
    }

    /**
     * Computes θ(t) at a specific time t.
     * @param t Time input
     * @return Phase in radians
     */
    public double getPhaseAt(double t) {
        return phaseFunction.get().applyAsDouble(t);
    }

    /**
     * Gets the associated prime number.
     */
    public int getPrimeValue() {
        return primeValue;
    }

    /**
     * Gets the current angular frequency ω.
     */
    public double getOmega() {
        return omega;
    }

    /**
     * Gets the amplitude A_i
     */
    public double getAmplitude() {
        return amplitude;
    }

    /**
     * Prime check utility.
     */
    private static boolean isPrime(int n) {
        if (n < 2) return false;
        if (n == 2 || n == 3) return true;
        if (n % 2 == 0) return false;
        for (int i = 3; i <= Math.sqrt(n); i += 2) {
            if (n % i == 0) return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return String.format("π_%d = %.4f * exp(i * θ(t))", primeValue, amplitude);
    }
}
