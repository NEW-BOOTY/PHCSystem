/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 *
 * PHCInterpreter.java
 * Symbolic and operational interpreter for Prime Harmonics Calculus (PHC).
 * Supports command parsing, time-evolution queries, vector superposition inspection,
 * and symbolic control over SpectralPrime and PrimeField.
 */

package engine;

import core.PrimeField;
import core.SpectralPrime;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class PHCInterpreter {

    private final PrimeField primeField;
    private final Map<String, SpectralPrime> bindings;

    public PHCInterpreter() {
        this.primeField = new PrimeField();
        this.bindings = new HashMap<>();
    }

    /**
     * Interprets and executes a PHC language statement.
     * @param input Symbolic instruction string.
     * @return Output result as string.
     */
    public String evaluate(String input) {
        Objects.requireNonNull(input, "Input cannot be null.");
        input = input.trim();

        if (input.isEmpty()) return "[NOOP]";

        try {
            if (input.startsWith("ADD ")) {
                return handleAdd(input);
            } else if (input.startsWith("FIELD AT ")) {
                return handleFieldAt(input);
            } else if (input.startsWith("NODES BETWEEN ")) {
                return handleNodeScan(input);
            } else if (input.equals("COUNT")) {
                return String.valueOf(primeField.getPrimeCount());
            } else if (input.equals("RESET")) {
                primeField.reset();
                bindings.clear();
                return "[FIELD RESET]";
            } else {
                return "[ERROR] Unknown command";
            }
        } catch (Exception ex) {
            return "[ERROR] " + ex.getMessage();
        }
    }

    /**
     * Adds a new SpectralPrime.
     * Format: ADD π7 = A=3.2 ω=π θ0=0
     */
    private String handleAdd(String line) {
        Pattern p = Pattern.compile("π(\\d+)\\s*=\\s*A=(\\d+(?:\\.\\d+)?)\\s*ω=([\\dπeE\\.]+)\\s*θ0=([\\d\\.\\-]+)");
        Matcher m = p.matcher(line.substring(4).trim());

        if (!m.matches()) throw new IllegalArgumentException("Invalid ADD syntax");

        int prime = Integer.parseInt(m.group(1));
        double amp = Double.parseDouble(m.group(2));
        double omega = parseMathConstant(m.group(3));
        double theta0 = Double.parseDouble(m.group(4));

        SpectralPrime sp = new SpectralPrime(prime, amp, omega, theta0);
        bindings.put("π" + prime, sp);
        primeField.addPrime(sp);

        return "[ADDED π" + prime + "]";
    }

    /**
     * Computes field value at given t.
     * Format: FIELD AT t=1.0
     */
    private String handleFieldAt(String line) {
        Pattern p = Pattern.compile("FIELD AT t=([\\d\\.\\-Eeπ]+)");
        Matcher m = p.matcher(line);
        if (!m.matches()) throw new IllegalArgumentException("Invalid FIELD AT syntax.");

        double t = parseMathConstant(m.group(1));
        double[] c = primeField.computeFieldAt(t);
        double mod = primeField.computeModulusAt(t);

        return String.format("Ω(t=%.4f) = %.6f + %.6fi |Ω| = %.6f", t, c[0], c[1], mod);
    }

    /**
     * Scans for zeros over an interval.
     * Format: NODES BETWEEN t0=0.0 t1=10.0 res=0.01 ε=0.001
     */
    private String handleNodeScan(String line) {
        Pattern p = Pattern.compile("NODES BETWEEN t0=([\\d\\.\\-Eeπ]+) t1=([\\d\\.\\-Eeπ]+) res=([\\d\\.]+) ε=([\\d\\.]+)");
        Matcher m = p.matcher(line);

        if (!m.matches()) throw new IllegalArgumentException("Invalid NODES BETWEEN syntax.");

        double t0 = parseMathConstant(m.group(1));
        double t1 = parseMathConstant(m.group(2));
        double res = Double.parseDouble(m.group(3));
        double eps = Double.parseDouble(m.group(4));

        List<Double> nodes = primeField.locateDestructiveNodes(t0, t1, res, eps);
        StringBuilder sb = new StringBuilder("Destructive Nodes:\n");
        for (double node : nodes) {
            sb.append(String.format("t=%.6f\n", node));
        }
        return sb.toString();
    }

    /**
     * Parses a symbolic constant expression.
     */
    private double parseMathConstant(String input) {
        String val = input.replaceAll("π", String.valueOf(Math.PI)).replaceAll("e", String.valueOf(Math.E));
        return Double.parseDouble(val);
    }

    /**
     * Returns the core PrimeField.
     */
    public PrimeField getPrimeField() {
        return primeField;
    }

    /**
     * Returns a copy of current variable bindings.
     */
    public Map<String, SpectralPrime> getBindingsSnapshot() {
        return Map.copyOf(bindings);
    }
}
